import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child-ab',
  templateUrl: './child-ab.component.html',
  styleUrls: ['./child-ab.component.scss']
})
export class ChildAbComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
