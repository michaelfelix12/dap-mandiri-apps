import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child-aa',
  templateUrl: './child-aa.component.html',
  styleUrls: ['./child-aa.component.scss']
})
export class ChildAaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
